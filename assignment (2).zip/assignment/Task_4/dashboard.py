import streamlit as st
import pandas as pd
import plotly.express as px

# setting up the Page configuration
st.set_page_config(
    page_title="Cyber Security Monitoring Dashboard",
    layout="wide"
)

st.title(" Local Government Cyber Security Dashboard")
st.caption("Prototype dashboard using two input files (network & endpoints)")

# LOADING  DATA OF NETWORK_TRAFFIC.CSV AND ENDPOINTS.CSV using pandas library
network = pd.read_csv("network_traffic.csv")
endpoints = pd.read_csv("endpoints.csv")

# defining the rows and columns for the visualization
st.header("Security Overview")

c1, c2, c3 = st.columns(3)

c1.metric("Total Network Events", len(network))
c2.metric("Endpoints with Malware Alerts", endpoints[endpoints["malware_alerts"] > 0].shape[0])
c3.metric("Firewalls Enabled", endpoints[endpoints["firewall_status"] == "On"].shape[0])

st.divider()

# Creating clear Visualization of  Network monitoring
st.header(" Network Traffic Monitoring")
col1, col2 = st.columns(2)

with col1:
    fig_protocol = px.pie(
        network,
        names="protocol",
        title="Network Protocol Distribution"
    )
    st.plotly_chart(fig_protocol, use_container_width=True)

with col2:
    fig_throughput = px.line(
        network,
        x="timestamp",
        y="throughput",
        title="Network Throughput Over Time"
    )
    st.plotly_chart(fig_throughput, use_container_width=True)

st.divider()

# Dashboard presenting ENDPOINT MONITORING
st.header(" Endpoint Security Monitoring")
col3, col4 = st.columns(2)

with col3:
    fig_malware = px.bar(
        endpoints,
        x="device",
        y="malware_alerts",
        title="Malware Alerts per Endpoint"
    )
    st.plotly_chart(fig_malware, use_container_width=True)

with col4:
    firewall_counts = endpoints["firewall_status"].value_counts().reset_index()
    firewall_counts.columns = ["Firewall Status", "Count"]

    fig_firewall = px.bar(
        firewall_counts,
        x="Firewall Status",
        y="Count",
        title="Firewall Status Distribution"
    )
    st.plotly_chart(fig_firewall, use_container_width=True)

st.success("This a Prototype dashboard of Network traffic and Endpoint security monitoring.")
